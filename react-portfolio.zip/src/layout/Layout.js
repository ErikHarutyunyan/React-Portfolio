import React from 'react';
import Home from '../pages/Home';

const Layout = () => {
  return <>
    <main>
      <Home />
    </main>
  </>;
};
export default Layout